namespace init {
extern const char* TAG;
void init_eventloop();
void init_mdns();
void init_netif();
void init_nvs();
void init_wifi();

void init_serial();
}  // namespace init
