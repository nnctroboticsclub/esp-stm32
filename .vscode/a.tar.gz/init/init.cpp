namespace init {
const char *TAG = "init";
}  // namespace init
